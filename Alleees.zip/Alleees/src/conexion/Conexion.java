//Esta clase sirve para conectar a la base de datos
package conexion;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;



public class Conexion {
    private static Connection CONN;
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String USER = "u611396439_allesrrhh";
    private static final String PASSWORD = "Caroyraul2023";
    private static final String URL = "jdbc:mysql://185.211.7.138:3306/u611396439_alles";
    
    public Conexion (){
        CONN = null;
        
    }
    
    //Metodo de retorno conexion 
    public Connection getConnection(){
        try {
            Class.forName(DRIVER);
            CONN = (Connection) DriverManager.getConnection(URL, USER, PASSWORD);
             
        } catch (ClassNotFoundException | SQLException ex) {
             JOptionPane.showMessageDialog(null, ex.getMessage(), "Error al conectar con la base de datos", JOptionPane.ERROR_MESSAGE);
             System.out.println("Error al conectar con la base de datos"+ex.getMessage());
             System.exit(0);
        }
        return CONN;
    }
    
    //Metodo para desconectar de bd
     public void desconectar (){
         try {
             CONN.close();
         } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, ex.getMessage(), "Error al desconectar de la base de datos", JOptionPane.ERROR_MESSAGE);
         }
         
     }
  
            }



