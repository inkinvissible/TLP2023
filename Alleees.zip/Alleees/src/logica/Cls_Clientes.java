package logica;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetInternalMethods;
import conexion.Conexion;
import java.awt.HeadlessException;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.xml.transform.Result;
import java.sql.ResultSet;
/**
 *
 * @author agusm
 */
public class Cls_Clientes {

    private final String SQL_INSERT = "INSERT INTO users (nombre, apellido, email, password, salt) values (?,?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM users";
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conexion CN;

    public Cls_Clientes() {
        PS = null;
        CN = new Conexion();
    }

    private DefaultTableModel setTitulos() {
        DT = new DefaultTableModel();
        DT.addColumn("Email");
        DT.addColumn("Nombre");
        DT.addColumn("Apellido");
        DT.addColumn("Contraseña");
        DT.addColumn("ID");

        return DT;
    }

    public int insertDatosClientes(String nom, String ape, String email, String pass, String salt) {
        int res = 0;
        try {
            PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_INSERT);
            PS.setString(1, nom.toUpperCase());
            PS.setString(2, ape.toUpperCase());
            PS.setString(3, email.toUpperCase());
            PS.setString(4, pass);
            PS.setString(5, salt);

            res = PS.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Registro Guradado");
            }
        } catch (SQLException e) {
            System.err.println("Error al guardar los datos en la bd: " + e.getMessage());
        } finally {
            PS = null;
            CN.desconectar();
        }
        return res;
    }

    public DefaultTableModel getDatosClientes() {
        try {
            setTitulos();
            PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL_SELECT);
            RS = PS.executeQuery();
            Object[] fila = new Object[10];
            while (RS.next()) {
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(2);
                fila[2] = RS.getString(3);
                fila[3] = RS.getString(4);
                fila[4] = RS.getString(5);

                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar los datos" + e.getMessage());
        } finally {
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }

    //Buscar Clientes
    public DefaultTableModel getDatoClientes(int crt, String prm) {
        String SQL;

        switch (crt) {
            case 0 ->
                SQL = "SELECT * FROM users WHERE nombre = '" + prm + "'";
            case 1 ->
                SQL = "SELECT * FROM users WHERE apellido = '" + prm + "'";
            case 2 ->
                SQL = "SELECT * FROM users WHERE email = '" + prm + "'";
            default ->
                throw new AssertionError();
        }
        try {
            setTitulos();
            PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();
            Object[] fila = new Object[10];
            while (RS.next()) {
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(2);
                fila[2] = RS.getString(3);
                fila[3] = RS.getString(4);

                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar los datos" + e.getMessage());
        } finally {
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    public int updateDatosClientes(String id, String nom, String ape, String email, String pass, String salt) {
        String SQL = "UPDATE users SET email='"+email+"',nombre='"+nom+"',apellido='"+ape+"',salt='"+salt+"' WHERE id="+id;
        int res = 0;
        try {
            PS = (PreparedStatement) CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Registro Modificado");
            }
        } catch (SQLException e) {
            System.err.println("Error al modificar los datos en la bd: " + e.getMessage());
        } finally {
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    //Eliminar Datos
    public int deleteClientes (String email){
        String SQL = "DELETE from users WHERE email = '" + email + "'";
        int res = 0;
        try {
            PS = (PreparedStatement) CN.getConnection().prepareStatement((SQL));
            res = PS.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Registro eliminado");
            }
        } catch (HeadlessException | SQLException e) {
            System.out.println("Error al eliminar los datos en la base de datos"+e.getMessage());
        }finally{
            PS=null;
            CN.desconectar();
        }
        return res;
    }
}

